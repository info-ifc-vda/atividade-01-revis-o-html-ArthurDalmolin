const form = document.getElementById('form-orcamento');
const feedback = document.getElementById('form-feedback');
const submitBtn = document.getElementById('submit-btn');
const fileInput = document.getElementById('arquivo');
const fileNameDisplay = document.getElementById('file-name');

// Mostrar nome do arquivo selecionado
fileInput.addEventListener('change', () => {
    if (fileInput.files.length > 0) {
        fileNameDisplay.textContent = "Arquivo selecionado: " + fileInput.files[0].name;
    } else {
        fileNameDisplay.textContent = "";
    }
});

form.addEventListener('submit', async function (e) {
    e.preventDefault();

    feedback.style.display = "none";
    feedback.className = "form-feedback";

    submitBtn.classList.add("btn-loading");
    submitBtn.textContent = "Enviando...";

    try {
        const file = fileInput.files[0];
        let base64 = "";

        if (file) {
            const reader = new FileReader();
            reader.readAsDataURL(file);

            await new Promise(resolve => {
                reader.onload = () => {
                    base64 = reader.result.split(',')[1];
                    resolve();
                };
            });
        }

        const data = {
            nome: form.nome.value,
            email: form.email.value,
            mensagem: form.mensagem.value,
            arquivo: base64,
            nomeArquivo: file ? file.name : ""
        };

        const response = await fetch("https://script.google.com/macros/s/AKfycbwbOuvvUPTzmCM5kfuUCpMacmbK_pIQUHVRIT92CIvwyOk8LgqbNGwl9ylonpK8jgOw/exec", {
            method: "POST",
            body: JSON.stringify(data)
        });

        if (!response.ok) throw new Error("Erro no envio");

        feedback.textContent = "✅ Orçamento enviado com sucesso! Entrarei em contato em breve.";
        feedback.classList.add("success");
        feedback.style.display = "block";

        form.reset();
        fileNameDisplay.textContent = "";

    } catch (error) {
        feedback.textContent = "❌ Ocorreu um erro ao enviar. Tente novamente.";
        feedback.classList.add("error");
        feedback.style.display = "block";
    }

    submitBtn.classList.remove("btn-loading");
    submitBtn.textContent = "Enviar";
});