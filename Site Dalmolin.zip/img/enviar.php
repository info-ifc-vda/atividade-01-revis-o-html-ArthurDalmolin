<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $documento = $_POST['documento'];
    $mensagem = $_POST['mensagem'];
    
    $para = "seu-email@dominio.com"; // Seu e-mail no HostGator
    $assunto = "Novo Orçamento - $nome";
    
    $corpo = "Nome: $nome\nEmail: $email\nDocumento: $documento\nMensagem: $mensagem";
    
    // Configurações básicas de envio (O HostGator cuidará do anexo se usar PHPMailer futuramente)
    if (mail($para, $assunto, $corpo, "From: $email")) {
        header("Location: index.html?sucesso=1#orcamento");
    } else {
        echo "Erro ao enviar.";
    }
}
?>